﻿using System;
using System.Text.RegularExpressions;
using System.Windows;

namespace FindDoubledLetters
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void FindButton_Click(object sender, RoutedEventArgs e)
        {
            string inputText = InputTextBox.Text;
            string pattern = @"(\w)\1";
            var matches = Regex.Matches(inputText, pattern);

            string result = "Удвоенные буквы: ";
            foreach (Match match in matches)
            {
                result += match.Value + " ";
            }

            OutputTextBox.Text = result;
        }
    }
}