﻿using System;
using System.Linq;
using System.Windows;

namespace LongestShortestWordWPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void FindWordsButton_Click(object sender, RoutedEventArgs e)
        {
            string text = TextInput.Text;
            string[] words = text.Split(new char[] { ' ', '.', ',', ';', ':' }, StringSplitOptions.RemoveEmptyEntries);

            string longestWord = words.OrderByDescending(w => w.Length).FirstOrDefault();
            string shortestWord = words.OrderBy(w => w.Length).FirstOrDefault();

            LongestWordTextBlock.Text = "Самое длинное слово: " + longestWord;
            ShortestWordTextBlock.Text = "Самое короткое слово: " + shortestWord;
        }
    }
}