﻿using System;
using System.Text.RegularExpressions;
using System.Windows;

namespace ReplaceUppercaseWithAsterisk
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ReplaceButton_Click(object sender, RoutedEventArgs e)
        {
            string inputText = InputTextBox.Text;
            string replacedText = Regex.Replace(inputText, "[а,А,о,О,у,У,ы,Ы,э,Э,е,Е,ё,Ё,и,И,ю,Ю,я,Я]", "*");

            OutputTextBox.Text = replacedText;
        }
    }
}