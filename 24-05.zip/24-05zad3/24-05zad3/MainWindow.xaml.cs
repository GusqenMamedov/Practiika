﻿using System;
using System.Windows;

namespace CountWords
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CountButton_Click(object sender, RoutedEventArgs e)
        {
            string inputText = InputTextBox.Text.Trim();
            string[] words = inputText.Split(new char[] { ' ', '\t', '\n', '\r', ',',';',':','.'}, StringSplitOptions.RemoveEmptyEntries);

            OutputTextBox.Text = $"Количество слов: {words.Length}";
        }
    }
}